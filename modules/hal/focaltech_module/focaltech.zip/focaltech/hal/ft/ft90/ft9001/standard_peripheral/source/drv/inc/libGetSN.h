/**
  **********************************************************************************
             Copyright(c) 2020 Focaltech Systems CO.,Ltd
                      All Rights Reserved
  **********************************************************************************
  * @file    GetSN.h
  * @author  Product application department
  * @version V1.0
  * @date    2021.09.13
  * @brief   GetSN����.
  *
  * @version V1.1
  * @date    2021.12.21
  * @brief   ȥ����ahb3_clk����.
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _GetSN_H_
#define _GetSN_H_
/**
 * @brief ��ȡоƬSN��8�ֽ�
 *
 * @param[in] *buff   :   SN����ָ��
 * @return
 */
extern void LIB_SN_Read(unsigned char * buff);

#endif /* _GetSN_H_ */

/************************ (C) COPYRIGHT Focaltech *****END OF FILE****/
