/**
  ******************************************************************************
             Copyright(c) 2020 Focaltech Co. Ltd.
                      All Rights Reserved
  ******************************************************************************
  * @file    libft9001.h
  * @author  Product application department
  * @version V1.0
  * @date    2020.03.25
  * @brief   Header file of FT9001 �⺯���ӿ�.
  * @note ��ӿڰ���
  *   - get sn �ӿ�
  *   - clk switch �ӿ�
  * 
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __LIBFT9001_H
#define __LIBFT9001_H

#ifdef __cplusplus
extern "C"
{
#endif

/* Includes ------------------------------------------------------------------*/
#include "type.h"

typedef enum
{
    OSC_320M_HZ = 0,
    OSC_360M_HZ,
    OSC_400M_HZ
} CPM_SysClkTrimTypeDef;

#ifdef FILE_OUT
/**@defgroup DRV 3 HAL driver
  *
  *@{
  */

/** @defgroup DRV_LIB LIB FT9001
  *
  *@{
  */
#endif
/*** �궨�� *******************************************************************/
#ifdef FILE_OUT
/** @defgroup DRV_LIB_Exported_Macros Exported Macros
  *
  * @{
  */
#endif
#define LOCK_JTAG_KEY 0xA5A5A5A5 /**<  */

/**
  * @}
  */

/*** �ṹ�塢ö�ٱ������� *****************************************************/
#ifdef FILE_OUT
/** @defgroup DRV_LIB_Exported_Types Exported Types
  *
  * @{
  */
#endif

/**
  * @}
  */

/*** ȫ�ֱ������� **************************************************************/
#ifdef FILE_OUT
/** @defgroup DRV_LIB_Exported_Variables Exported Variables
  *
  * @{
  */
#endif

/**
  * @}
  */

/*** �������� ******************************************************************/
#ifdef FILE_OUT
/** @defgroup DRV_LIB_Exported_Functions Exported Functions
  * @{
  */
#endif

    /* ��ȡ��İ汾 */
    extern uint8_t *Lib_GetVersion(void);

    /* EFLASH �����ӿ� */
    //extern uint8_t LIB_EFLASH_Disboot(void);

    //extern uint8_t LIB_EFLASH_RecoveryToBoot(void);

    /* ��ȡоƬSN�ź����ӿڣ�����8�ֽ� */
    extern void LIB_GetSerialNumber(uint8_t *buff);

    /* ʱ��Դ�л��ӿ� */
    extern void LIB_CPM_OscSwitch(int32_t osc_sel);

    extern uint8_t LIB_sysclock400_check(void);
    /**
  * @}
  */

    /**
  *@}
  */

    /**
  *@}
  */

#ifdef __cplusplus
}
#endif

#endif /* __LIBFT9001_H */

/************************ (C) COPYRIGHT Focaltech *****END OF FILE****/
